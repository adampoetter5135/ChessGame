package chess;

public class chess {

	public static void main(String[] args) {
		System.out.println("chess");
		// TODO Auto-generated method stub

	}

}
